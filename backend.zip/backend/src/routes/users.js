const { Router } = require('express');
const router = Router();
//Módulo Faker para pruebas
const faker = require('faker');
const Ciudad = require('../models/Ciudad')

//ÉSTA ES LA RUTA DE LA API en ciudad
router.get('/api/ciudad', async (req, res)=>{
    const ciudades = await Ciudad.find();
    res.json(ciudades); //Solo puede haber un res.json
});

//Esta ruta va a crear datos aleatorios.
router.get('/api/ciudad/crear', async (req, res) =>{
    for(let i = 0; i < 5; i++){
        const c = Math.random()*(6-1)+1;
        const c2= -c;
        await Ciudad.create({
            woeid: (Math.random()*(1000000-1000)+1).toString(),
            nombre: faker.address.cityName(),
            imagen: faker.image.city(),
            temperatura: (Math.random()*(47-c)+1).toString()
            /*d1: Math.random()*(47-c)+1,
            d2: Math.random()*(47-c)+1,
            d3: Math.random()*(47-c)+1,
            d4: Math.random()*(47-c)+1,
            d5: Math.random()*(47-c)+1,
            d6: Math.random()*(47-c)+1,*/
        });
    }
    res.json({message:'5 ciudades creadas para cuestiones de práctica'});
});

module.exports = router;
