const {Schema, model} = require('mongoose');
//Aquí se define la forma de guardado de información de las ciudades
const ciudadSchema = new Schema({
    woeid: String,
    nombre: String,
    imagen: String,
    temperatura: String
    /*d1: Number,
    d2: Number,
    d3: Number,
    d4: Number,
    d5: Number,
    d6: Number*/
});

model.exports = ('Ciudad', ciudadSchema);