const mongoose = require("mongoose");

async function connect() {
  await mongoose.connect('mongodb://localhost/clima', {
    useNewUrlParser: true,
  });
  console.log('DATABASE CONNECTED');
};

module.exports = {connect};
